package com.spring.service;

import com.spring.dao.IDaoPhone;

public interface IServicePhone extends IDaoPhone {
    
}
