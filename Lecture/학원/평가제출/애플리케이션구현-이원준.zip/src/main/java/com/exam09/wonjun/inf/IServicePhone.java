package com.exam09.wonjun.inf;

public interface IServicePhone extends IDaoPhone {

}
